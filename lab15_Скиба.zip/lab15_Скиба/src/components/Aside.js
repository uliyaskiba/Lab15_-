import React from 'react';

const Aside = () => {
    return (
        <aside style={{ borderLeft: '1px solid #ccc', padding: '10px' }}>
            <p>Скиба Юлия Александровна</p>
        </aside>
    );
};

export default Aside;
